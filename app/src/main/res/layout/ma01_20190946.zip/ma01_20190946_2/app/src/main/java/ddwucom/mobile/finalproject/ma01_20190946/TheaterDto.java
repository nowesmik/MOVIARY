package ddwucom.mobile.finalproject.ma01_20190946;

import java.io.Serializable;

public class TheaterDto implements Serializable {

}
